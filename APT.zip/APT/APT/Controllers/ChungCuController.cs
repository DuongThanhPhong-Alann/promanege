﻿using APT.Model;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using APT.Services;
[Route("api/[controller]")]
[ApiController]
public class ChungCuController : ControllerBase
{
    private readonly ChungCuService _chungCuService;

    public ChungCuController(ChungCuService chungCuService)
    {
        _chungCuService = chungCuService;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<ChungCu>>> GetAll()
    {
        return Ok(await _chungCuService.GetAllAsync());
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<ChungCu>> GetById(int id)
    {
        var chungCu = await _chungCuService.GetByIdAsync(id);
        if (chungCu == null) return NotFound();
        return Ok(chungCu);
    }

    [HttpPost]
    public async Task<ActionResult> Create([FromBody] ChungCu chungCu)
    {
        await _chungCuService.AddAsync(chungCu);
        return CreatedAtAction(nameof(GetById), new { id = chungCu.ID }, chungCu);
    }

    [HttpPut("{id}")]
    public async Task<ActionResult> Update(int id, [FromBody] ChungCu chungCu)
    {
        if (id != chungCu.ID) return BadRequest();
        await _chungCuService.UpdateAsync(chungCu);
        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<ActionResult> Delete(int id)
    {
        await _chungCuService.DeleteAsync(id);
        return NoContent();
    }
}
