﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace APT.Migrations
{
    /// <inheritdoc />
    public partial class Initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ChungCus",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Ten = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DiaChi = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ChuDauTu = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    NamXayDung = table.Column<int>(type: "int", nullable: false),
                    SoTang = table.Column<int>(type: "int", nullable: false),
                    MoTa = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ChungCus", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "DichVus",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TenDichVu = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MoTa = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Gia = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DichVus", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "NguoiDungs",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    HoTen = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SoDienThoai = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MatKhau = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LoaiNguoiDung = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_NguoiDungs", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CanHos",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MaCan = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ID_ChungCu = table.Column<int>(type: "int", nullable: false),
                    DienTich = table.Column<double>(type: "float", nullable: false),
                    SoPhong = table.Column<int>(type: "int", nullable: false),
                    Gia = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    TrangThai = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ChungCuID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CanHos", x => x.ID);
                    table.ForeignKey(
                        name: "FK_CanHos_ChungCus_ChungCuID",
                        column: x => x.ChungCuID,
                        principalTable: "ChungCus",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "HinhAnhChungCus",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ID_ChungCu = table.Column<int>(type: "int", nullable: false),
                    DuongDan = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ChungCuID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HinhAnhChungCus", x => x.ID);
                    table.ForeignKey(
                        name: "FK_HinhAnhChungCus_ChungCus_ChungCuID",
                        column: x => x.ChungCuID,
                        principalTable: "ChungCus",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "PhanAnhs",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ID_NguoiDung = table.Column<int>(type: "int", nullable: false),
                    NoiDung = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TrangThai = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    NgayGui = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PhanAnhs", x => x.ID);
                    table.ForeignKey(
                        name: "FK_PhanAnhs_NguoiDungs_ID_NguoiDung",
                        column: x => x.ID_NguoiDung,
                        principalTable: "NguoiDungs",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "CuDans",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ID_NguoiDung = table.Column<int>(type: "int", nullable: false),
                    ID_CanHo = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CuDans", x => x.ID);
                    table.ForeignKey(
                        name: "FK_CuDans_CanHos_ID_CanHo",
                        column: x => x.ID_CanHo,
                        principalTable: "CanHos",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_CuDans_NguoiDungs_ID_NguoiDung",
                        column: x => x.ID_NguoiDung,
                        principalTable: "NguoiDungs",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "HinhAnhCanHos",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ID_CanHo = table.Column<int>(type: "int", nullable: false),
                    DuongDan = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CanHoID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HinhAnhCanHos", x => x.ID);
                    table.ForeignKey(
                        name: "FK_HinhAnhCanHos_CanHos_CanHoID",
                        column: x => x.CanHoID,
                        principalTable: "CanHos",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "HoaDonDichVus",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ID_CanHo = table.Column<int>(type: "int", nullable: false),
                    ID_DichVu = table.Column<int>(type: "int", nullable: false),
                    NgayLap = table.Column<DateTime>(type: "datetime2", nullable: false),
                    SoTien = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    TrangThai = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HoaDonDichVus", x => x.ID);
                    table.ForeignKey(
                        name: "FK_HoaDonDichVus_CanHos_ID_CanHo",
                        column: x => x.ID_CanHo,
                        principalTable: "CanHos",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_HoaDonDichVus_DichVus_ID_DichVu",
                        column: x => x.ID_DichVu,
                        principalTable: "DichVus",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_CanHos_ChungCuID",
                table: "CanHos",
                column: "ChungCuID");

            migrationBuilder.CreateIndex(
                name: "IX_CuDans_ID_CanHo",
                table: "CuDans",
                column: "ID_CanHo");

            migrationBuilder.CreateIndex(
                name: "IX_CuDans_ID_NguoiDung",
                table: "CuDans",
                column: "ID_NguoiDung");

            migrationBuilder.CreateIndex(
                name: "IX_HinhAnhCanHos_CanHoID",
                table: "HinhAnhCanHos",
                column: "CanHoID");

            migrationBuilder.CreateIndex(
                name: "IX_HinhAnhChungCus_ChungCuID",
                table: "HinhAnhChungCus",
                column: "ChungCuID");

            migrationBuilder.CreateIndex(
                name: "IX_HoaDonDichVus_ID_CanHo",
                table: "HoaDonDichVus",
                column: "ID_CanHo");

            migrationBuilder.CreateIndex(
                name: "IX_HoaDonDichVus_ID_DichVu",
                table: "HoaDonDichVus",
                column: "ID_DichVu");

            migrationBuilder.CreateIndex(
                name: "IX_PhanAnhs_ID_NguoiDung",
                table: "PhanAnhs",
                column: "ID_NguoiDung");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CuDans");

            migrationBuilder.DropTable(
                name: "HinhAnhCanHos");

            migrationBuilder.DropTable(
                name: "HinhAnhChungCus");

            migrationBuilder.DropTable(
                name: "HoaDonDichVus");

            migrationBuilder.DropTable(
                name: "PhanAnhs");

            migrationBuilder.DropTable(
                name: "CanHos");

            migrationBuilder.DropTable(
                name: "DichVus");

            migrationBuilder.DropTable(
                name: "NguoiDungs");

            migrationBuilder.DropTable(
                name: "ChungCus");
        }
    }
}
