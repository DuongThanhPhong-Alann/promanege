﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace APT.Migrations
{
    /// <inheritdoc />
    public partial class api : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "TrangThai",
                table: "HoaDonDichVus");

            migrationBuilder.AddColumn<int>(
                name: "CuDanID",
                table: "HoaDonDichVus",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ID_CuDan",
                table: "HoaDonDichVus",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "TrangThaiThanhToan",
                table: "HoaDonDichVus",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.CreateIndex(
                name: "IX_HoaDonDichVus_CuDanID",
                table: "HoaDonDichVus",
                column: "CuDanID");

            migrationBuilder.AddForeignKey(
                name: "FK_HoaDonDichVus_CuDans_CuDanID",
                table: "HoaDonDichVus",
                column: "CuDanID",
                principalTable: "CuDans",
                principalColumn: "ID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_HoaDonDichVus_CuDans_CuDanID",
                table: "HoaDonDichVus");

            migrationBuilder.DropIndex(
                name: "IX_HoaDonDichVus_CuDanID",
                table: "HoaDonDichVus");

            migrationBuilder.DropColumn(
                name: "CuDanID",
                table: "HoaDonDichVus");

            migrationBuilder.DropColumn(
                name: "ID_CuDan",
                table: "HoaDonDichVus");

            migrationBuilder.DropColumn(
                name: "TrangThaiThanhToan",
                table: "HoaDonDichVus");

            migrationBuilder.AddColumn<string>(
                name: "TrangThai",
                table: "HoaDonDichVus",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
