﻿using Microsoft.EntityFrameworkCore;
namespace APT.Model
{

    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<ChungCu> ChungCus { get; set; }
        public DbSet<HinhAnhChungCu> HinhAnhChungCus { get; set; }
        public DbSet<CanHo> CanHos { get; set; }
        public DbSet<HinhAnhCanHo> HinhAnhCanHos { get; set; }
        public DbSet<NguoiDung> NguoiDungs { get; set; }
        public DbSet<CuDan> CuDans { get; set; }
        public DbSet<DichVu> DichVus { get; set; }
        public DbSet<HoaDonDichVu> HoaDonDichVus { get; set; }
        public DbSet<PhanAnh> PhanAnhs { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CuDan>()
                .HasOne(c => c.NguoiDung)
                .WithMany(n => n.CuDans)
                .HasForeignKey(c => c.ID_NguoiDung);

            modelBuilder.Entity<CuDan>()
                .HasOne(c => c.CanHo)
                .WithMany(ch => ch.CuDans)
                .HasForeignKey(c => c.ID_CanHo);

            modelBuilder.Entity<HoaDonDichVu>()
                .HasOne(h => h.CanHo)
                .WithMany()
                .HasForeignKey(h => h.ID_CanHo);

            modelBuilder.Entity<HoaDonDichVu>()
                .HasOne(h => h.DichVu)
                .WithMany(d => d.HoaDonDichVus)
                .HasForeignKey(h => h.ID_DichVu);

            modelBuilder.Entity<PhanAnh>()
                .HasOne(p => p.NguoiDung)
                .WithMany(n => n.PhanAnhs)
                .HasForeignKey(p => p.ID_NguoiDung);
        }
    }

}
