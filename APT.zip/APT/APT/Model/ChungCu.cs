﻿namespace APT.Model
{
    public class ChungCu
    {
        public int ID { get; set; }
        public string? Ten { get; set; }
        public string? DiaChi { get; set; }
        public string? ChuDauTu { get; set; }
        public int NamXayDung { get; set; }
        public int SoTang { get; set; }
        public string? MoTa { get; set; }

        // Danh sách ảnh của chung cư
        public ICollection<HinhAnhChungCu>? HinhAnhs { get; set; }
        public ICollection<CanHo>? CanHos { get; set; }
    }

}
