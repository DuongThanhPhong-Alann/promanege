﻿
using APT.Services;
using APT.Repositories;
using Microsoft.EntityFrameworkCore;
using APT.Model;

var builder = WebApplication.CreateBuilder(args);

// 🔹 Lấy chuỗi kết nối từ appsettings.json
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");

// 🔹 Đăng ký DbContext với SQL Server
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(connectionString));

// 🔹 Cấu hình CORS (cho phép API được gọi từ nguồn khác)
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll",
        policy => policy.AllowAnyOrigin()
                        .AllowAnyMethod()
                        .AllowAnyHeader());
});

// 🔹 Đăng ký Repository
builder.Services.AddScoped<ChungCuRepository>();
builder.Services.AddScoped<CanHoRepository>();
builder.Services.AddScoped<NguoiDungRepository>();
builder.Services.AddScoped<CuDanRepository>();
builder.Services.AddScoped<DichVuRepository>();
builder.Services.AddScoped<HoaDonDichVuRepository>();
builder.Services.AddScoped<PhanAnhRepository>();

// 🔹 Đăng ký Service
builder.Services.AddScoped<ChungCuService>();
builder.Services.AddScoped<CanHoService>();
builder.Services.AddScoped<NguoiDungService>();
builder.Services.AddScoped<CuDanService>();
builder.Services.AddScoped<DichVuService>();
builder.Services.AddScoped<HoaDonDichVuService>();
builder.Services.AddScoped<PhanAnhService>();
builder.Services.AddScoped<HinhAnhChungCuService>();
builder.Services.AddScoped<HinhAnhCanHoService>();

// 🔹 Thêm dịch vụ cho Controller
builder.Services.AddControllers();

// 🔹 Thêm Swagger để test API
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// 🔹 Cấu hình Middleware
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseCors("AllowAll"); // Kích hoạt CORS
app.UseAuthorization();
app.MapControllers(); // Định tuyến API

app.Run();
