﻿using APT.Model;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;



namespace APT.Repositories
{
    public class CuDanRepository : RepositoryBase<CuDan>
    {
        public CuDanRepository(ApplicationDbContext context) : base(context) { }

        public async Task<IEnumerable<CuDan>> GetAllWithDetailsAsync()
        {
            return await _context.CuDans.Include(c => c.NguoiDung).Include(c => c.CanHo).ToListAsync();
        }
    }
}