﻿using APT.Model;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;


namespace APT.Repositories
{
    public class DichVuRepository : RepositoryBase<DichVu>
    {
        public DichVuRepository(ApplicationDbContext context) : base(context) { }
    }
}