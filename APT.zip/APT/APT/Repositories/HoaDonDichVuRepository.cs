﻿using APT.Model;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;




namespace APT.Repositories
{
    public class HoaDonDichVuRepository : RepositoryBase<HoaDonDichVu>
    {
        public HoaDonDichVuRepository(ApplicationDbContext context) : base(context) { }

        public async Task<IEnumerable<HoaDonDichVu>> GetAllWithDetailsAsync()
        {
            return await _context.HoaDonDichVus.Include(h => h.CanHo).Include(h => h.DichVu).ToListAsync();
        }
    }
}