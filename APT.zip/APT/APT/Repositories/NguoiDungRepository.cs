﻿using APT.Model;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;


namespace APT.Repositories
{
    public class NguoiDungRepository : RepositoryBase<NguoiDung>
    {
        public NguoiDungRepository(ApplicationDbContext context) : base(context) { }
    }
}
