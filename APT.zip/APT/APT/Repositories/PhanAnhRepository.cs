﻿using APT.Model;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;


namespace APT.Repositories
{
    public class PhanAnhRepository : RepositoryBase<PhanAnh>
    {
        public PhanAnhRepository(ApplicationDbContext context) : base(context) { }

        public async Task<IEnumerable<PhanAnh>> GetAllWithUserAsync()
        {
            return await _context.PhanAnhs.Include(p => p.NguoiDung).ToListAsync();
        }
    }

}