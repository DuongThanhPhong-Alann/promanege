﻿
using APT.Model;
using Microsoft.EntityFrameworkCore;

namespace APT.Services
{
    public class HinhAnhCanHoService
    {
        private readonly ApplicationDbContext _context;

        public HinhAnhCanHoService(ApplicationDbContext context)
        {
            _context = context;
        }

        // 📌 Lấy danh sách hình ảnh theo ID căn hộ
        public async Task<List<HinhAnhCanHo>> GetByCanHoIdAsync(int canHoId)
        {
            return await _context.HinhAnhCanHos
                .Where(a => a.ID_CanHo == canHoId)
                .ToListAsync();
        }

        // 📌 Lấy hình ảnh theo ID
        public async Task<HinhAnhCanHo?> GetByIdAsync(int id)
        {
            return await _context.HinhAnhCanHos.FindAsync(id);
        }

        // 📌 Thêm hình ảnh mới
        public async Task<bool> AddAsync(HinhAnhCanHo hinhAnhCanHo)
        {
            _context.HinhAnhCanHos.Add(hinhAnhCanHo);
            return await _context.SaveChangesAsync() > 0;
        }

        // 📌 Cập nhật hình ảnh
        public async Task<bool> UpdateAsync(HinhAnhCanHo hinhAnhCanHo)
        {
            _context.HinhAnhCanHos.Update(hinhAnhCanHo);
            return await _context.SaveChangesAsync() > 0;
        }

        // 📌 Xóa hình ảnh
        public async Task<bool> DeleteAsync(int id)
        {
            var hinhAnhCanHo = await _context.HinhAnhCanHos.FindAsync(id);
            if (hinhAnhCanHo == null) return false;

            _context.HinhAnhCanHos.Remove(hinhAnhCanHo);
            return await _context.SaveChangesAsync() > 0;
        }
    }
}
