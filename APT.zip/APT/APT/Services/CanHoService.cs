﻿using System.Collections.Generic;
using System.Threading.Tasks;
using APT.Model;
using APT.Repositories;


namespace APT.Services
{
    public class CanHoService : ServiceBase<CanHo>
    {
        private readonly CanHoRepository _repository;

        public CanHoService(CanHoRepository repository) : base(repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<CanHo>> GetAllWithImagesAsync()
        {
            return await _repository.GetAllWithImagesAsync();
        }
    }
}