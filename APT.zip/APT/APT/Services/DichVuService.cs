﻿using System.Collections.Generic;
using System.Threading.Tasks;
using APT.Model;


using APT.Repositories;


namespace APT.Services
{
    public class DichVuService : ServiceBase<DichVu>
    {
        public DichVuService(DichVuRepository repository) : base(repository) { }
    }
}