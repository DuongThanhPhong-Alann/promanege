﻿
using APT.Model;
using Microsoft.EntityFrameworkCore;

namespace APT.Services
{
    public class HinhAnhChungCuService
    {
        private readonly ApplicationDbContext _context;

        public HinhAnhChungCuService(ApplicationDbContext context)
        {
            _context = context;
        }

        // 📌 Lấy danh sách hình ảnh theo ID chung cư
        public async Task<List<HinhAnhChungCu>> GetByChungCuIdAsync(int chungCuId)
        {
            return await _context.HinhAnhChungCus
                .Where(a => a.ID_ChungCu == chungCuId)
                .ToListAsync();
        }

        // 📌 Lấy hình ảnh theo ID
        public async Task<HinhAnhChungCu?> GetByIdAsync(int id)
        {
            return await _context.HinhAnhChungCus.FindAsync(id);
        }

        // 📌 Thêm hình ảnh mới
        public async Task<bool> AddAsync(HinhAnhChungCu hinhAnhChungCu)
        {
            _context.HinhAnhChungCus.Add(hinhAnhChungCu);
            return await _context.SaveChangesAsync() > 0;
        }

        // 📌 Cập nhật hình ảnh
        public async Task<bool> UpdateAsync(HinhAnhChungCu hinhAnhChungCu)
        {
            _context.HinhAnhChungCus.Update(hinhAnhChungCu);
            return await _context.SaveChangesAsync() > 0;
        }

        // 📌 Xóa hình ảnh
        public async Task<bool> DeleteAsync(int id)
        {
            var hinhAnhChungCu = await _context.HinhAnhChungCus.FindAsync(id);
            if (hinhAnhChungCu == null) return false;

            _context.HinhAnhChungCus.Remove(hinhAnhChungCu);
            return await _context.SaveChangesAsync() > 0;
        }
    }
}
