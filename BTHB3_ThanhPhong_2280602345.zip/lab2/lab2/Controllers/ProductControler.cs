﻿using lab2.Models;
using lab2.Repository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace lab2.Controllers
{
    public class ProductController : Controller
    {
        private readonly IProductRepository _productRepository;
        private readonly ICategoryRepository _categoryRepository;

        public ProductController(IProductRepository productRepository, ICategoryRepository categoryRepository)
        {
            _productRepository = productRepository;
            _categoryRepository = categoryRepository;
        }

        // Hiển thị danh sách sản phẩm
        public async Task<IActionResult> Index()
        {
            var products = await _productRepository.GetAllAsync();
            return View(products);
        }

        // Hiển thị form thêm sản phẩm
        public async Task<IActionResult> Add()
        {
            var categories = await _categoryRepository.GetAllAsync();
            ViewBag.Categories = new SelectList(categories, "Id", "Name_");
            return View();
        }

        // Xử lý thêm sản phẩm mới (Hỗ trợ cả chọn ảnh hoặc nhập link ảnh)
        [HttpPost]
        public async Task<IActionResult> Add(Product product, IFormFile? imageFile, string? imageUrl)
        {
            if (ModelState.IsValid)
            {
                if (imageFile != null)
                {
                    product.ImageUrl = await SaveImage(imageFile); // Lưu ảnh từ máy
                }
                else if (!string.IsNullOrEmpty(imageUrl))
                {
                    product.ImageUrl = imageUrl; // Dùng link ảnh nhập vào
                }

                await _productRepository.AddAsync(product);
                return RedirectToAction(nameof(Index));
            }

            var categories = await _categoryRepository.GetAllAsync();
            ViewBag.Categories = new SelectList(categories, "Id", "Name_");
            return View(product);
        }

        // Hiển thị form cập nhật sản phẩm
        public async Task<IActionResult> Update(int id)
        {
            var product = await _productRepository.GetByIdAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            var categories = await _categoryRepository.GetAllAsync() ?? new List<Category>();
            ViewBag.Categories = new SelectList(categories, "Id", "Name_", product.CategoryId);
            return View(product);
        }

        // Xử lý cập nhật sản phẩm (Hỗ trợ chọn ảnh hoặc nhập link ảnh)
        [HttpPost]
        public async Task<IActionResult> Update(int id, Product product, IFormFile? imageFile, string? imageUrl)
        {
            if (id != product.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                var existingProduct = await _productRepository.GetByIdAsync(id);
                if (existingProduct == null)
                {
                    return NotFound();
                }

                existingProduct.Name_ = product.Name_;
                existingProduct.Price = product.Price;
                existingProduct.Description_ = product.Description_;
                existingProduct.CategoryId = product.CategoryId;

                if (imageFile != null)
                {
                    existingProduct.ImageUrl = await SaveImage(imageFile);
                }
                else if (!string.IsNullOrEmpty(imageUrl))
                {
                    existingProduct.ImageUrl = imageUrl;
                }

                await _productRepository.UpdateAsync(existingProduct);
                return RedirectToAction(nameof(Index));
            }

            var categories = await _categoryRepository.GetAllAsync();
            ViewBag.Categories = new SelectList(categories, "Id", "Name_", product.CategoryId);
            return View(product);
        }

        // Lưu ảnh lên server
        private async Task<string> SaveImage(IFormFile image)
        {
            if (image == null || image.Length == 0)
            {
                return string.Empty;
            }

            string uniqueFileName = $"{Guid.NewGuid()}_{image.FileName}";
            string uploadFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images");

            Directory.CreateDirectory(uploadFolder); // Tạo thư mục nếu chưa có

            string filePath = Path.Combine(uploadFolder, uniqueFileName);

            using (var fileStream = new FileStream(filePath, FileMode.Create))
            {
                await image.CopyToAsync(fileStream);
            }

            return $"/images/{uniqueFileName}";
        }

        // Hiển thị trang chi tiết sản phẩm

        public async Task<IActionResult> Display(int id)
        {
            var product = await _productRepository.GetByIdAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            var category = await _categoryRepository.GetByIdAsync(product.CategoryId);
            ViewBag.CategoryName = category?.Name_;

            return View(product);
        }


        // Hiển thị form xác nhận xóa sản phẩm
        public async Task<IActionResult> Delete(int id)
        {
            var product = await _productRepository.GetByIdAsync(id);
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }

        // Xử lý xóa sản phẩm
        [HttpPost, ActionName("DeleteConfirmed")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _productRepository.DeleteAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }
}
