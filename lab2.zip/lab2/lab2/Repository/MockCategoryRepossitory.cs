﻿//using System.Collections.Generic;
//using lab2.Models;
//using System.Linq;
//using lab2.Repository;

//namespace lab2.Repository
//{
//    public class MockCategoryRepository : ICategoryRepository
//    {
//        private List<Category> _categoryList;
//        public MockCategoryRepository()
//        {
//            _categoryList = new List<Category>
//             {
//             new Category { Id = 1, Name_ = "Laptop" },
//             new Category { Id = 2, Name_ = "Desktop" },
            
//             };
//        }
//        public IEnumerable<Category> GetAllCategories()
//        {
//            return _categoryList;
//        }
//    }
//}
